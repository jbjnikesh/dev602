 sap.ui.controller("sap.shineNext.odataBasic.view.App",{
	
}); 
